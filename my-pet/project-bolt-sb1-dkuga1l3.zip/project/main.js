import './style.css'

const STORAGE_KEY = 'digital-pet-state'

let petState = {
  hunger: 100,
  happiness: 100,
  cleanliness: 100,
  energy: 100,
  isSleeping: false,
  lastUpdate: Date.now()
}

const elements = {
  pet: document.getElementById('pet'),
  petStatus: document.getElementById('petStatus'),
  hungerBar: document.getElementById('hungerBar'),
  hungerValue: document.getElementById('hungerValue'),
  happinessBar: document.getElementById('happinessBar'),
  happinessValue: document.getElementById('happinessValue'),
  cleanBar: document.getElementById('cleanBar'),
  cleanValue: document.getElementById('cleanValue'),
  energyBar: document.getElementById('energyBar'),
  energyValue: document.getElementById('energyValue'),
  feedBtn: document.getElementById('feedBtn'),
  playBtn: document.getElementById('playBtn'),
  bathBtn: document.getElementById('bathBtn'),
  sleepBtn: document.getElementById('sleepBtn')
}

function savePetState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(petState))
}

function loadPetState() {
  const saved = localStorage.getItem(STORAGE_KEY)
  if (saved) {
    try {
      const data = JSON.parse(saved)
      petState = {
        hunger: data.hunger,
        happiness: data.happiness,
        cleanliness: data.cleanliness,
        energy: data.energy,
        isSleeping: data.isSleeping,
        lastUpdate: data.lastUpdate
      }
      applyTimeBasedDecay()
    } catch (error) {
      console.error('Error loading pet state:', error)
    }
  }
}

function applyTimeBasedDecay() {
  const now = Date.now()
  const timePassed = now - petState.lastUpdate
  const minutesPassed = timePassed / (1000 * 60)

  if (minutesPassed > 0) {
    petState.hunger = Math.max(0, petState.hunger - (minutesPassed * 0.5))
    petState.happiness = Math.max(0, petState.happiness - (minutesPassed * 0.3))
    petState.cleanliness = Math.max(0, petState.cleanliness - (minutesPassed * 0.2))
    if (!petState.isSleeping) {
      petState.energy = Math.max(0, petState.energy - (minutesPassed * 0.4))
    }
    petState.lastUpdate = now
  }
}

function updateStatBar(bar, valueLabel, value) {
  const clampedValue = Math.max(0, Math.min(100, value))
  bar.style.width = `${clampedValue}%`
  valueLabel.textContent = `${Math.round(clampedValue)}%`

  bar.classList.remove('low', 'medium')
  if (clampedValue < 30) {
    bar.classList.add('low')
  } else if (clampedValue < 60) {
    bar.classList.add('medium')
  }
}

function updateUI() {
  updateStatBar(elements.hungerBar, elements.hungerValue, petState.hunger)
  updateStatBar(elements.happinessBar, elements.happinessValue, petState.happiness)
  updateStatBar(elements.cleanBar, elements.cleanValue, petState.cleanliness)
  updateStatBar(elements.energyBar, elements.energyValue, petState.energy)

  const sleepBtnIcon = elements.sleepBtn.querySelector('.btn-icon')
  const sleepBtnText = elements.sleepBtn.querySelector('.btn-text')
  if (petState.isSleeping) {
    sleepBtnIcon.textContent = '⏰'
    sleepBtnText.textContent = 'Wake'
  } else {
    sleepBtnIcon.textContent = '💤'
    sleepBtnText.textContent = 'Sleep'
  }
}

function showStatus(emoji, duration = 2000) {
  elements.petStatus.textContent = emoji
  setTimeout(() => {
    elements.petStatus.textContent = ''
  }, duration)
}

function addPetAnimation(className, duration = 600) {
  elements.pet.classList.add(className)
  setTimeout(() => {
    elements.pet.classList.remove(className)
  }, duration)
}

function disableButtons(duration) {
  const buttons = [elements.feedBtn, elements.playBtn, elements.bathBtn, elements.sleepBtn]
  buttons.forEach(btn => btn.disabled = true)
  setTimeout(() => {
    buttons.forEach(btn => btn.disabled = false)
  }, duration)
}

function decreaseStats() {
  if (!petState.isSleeping) {
    petState.hunger = Math.max(0, petState.hunger - 0.5)
    petState.happiness = Math.max(0, petState.happiness - 0.3)
    petState.cleanliness = Math.max(0, petState.cleanliness - 0.2)
    petState.energy = Math.max(0, petState.energy - 0.4)
  }
  petState.lastUpdate = Date.now()
  updateUI()
  savePetState()
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      console.log('Service Worker registration failed')
    })
  })
}

elements.feedBtn.addEventListener('click', () => {
  if (petState.isSleeping) {
    showStatus('😴')
    return
  }

  petState.hunger = Math.min(100, petState.hunger + 25)
  petState.happiness = Math.min(100, petState.happiness + 5)
  showStatus('🍖')
  addPetAnimation('happy')
  disableButtons(600)
  updateUI()
  savePetState()
})

elements.playBtn.addEventListener('click', () => {
  if (petState.isSleeping) {
    showStatus('😴')
    return
  }

  if (petState.energy < 20) {
    showStatus('😫')
    return
  }

  petState.happiness = Math.min(100, petState.happiness + 30)
  petState.energy = Math.max(0, petState.energy - 15)
  petState.hunger = Math.max(0, petState.hunger - 10)
  showStatus('⚽')
  addPetAnimation('playing', 2000)
  disableButtons(2000)
  updateUI()
  savePetState()
})

elements.bathBtn.addEventListener('click', () => {
  if (petState.isSleeping) {
    showStatus('😴')
    return
  }

  petState.cleanliness = Math.min(100, petState.cleanliness + 40)
  petState.happiness = Math.min(100, petState.happiness + 10)
  showStatus('✨')
  addPetAnimation('bathing', 500)
  disableButtons(500)
  updateUI()
  savePetState()
})

elements.sleepBtn.addEventListener('click', () => {
  petState.isSleeping = !petState.isSleeping

  if (petState.isSleeping) {
    showStatus('💤', 3000)
    elements.pet.classList.add('sleeping')
    petState.energy = Math.min(100, petState.energy + 50)
  } else {
    showStatus('👋')
    elements.pet.classList.remove('sleeping')
  }

  disableButtons(600)
  updateUI()
  savePetState()
})

loadPetState()
updateUI()
setInterval(decreaseStats, 60000)
